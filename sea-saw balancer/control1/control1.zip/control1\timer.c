#include<p33FJ128MC804.h>

int configure_timer_T1(void)
{
	T1CONbits.TON = 0; // Disable Timer
	T1CONbits.TCS = 0; // Select internal instruction cycle clock
	T1CONbits.TGATE = 0; // Disable Gated Timer mode
	T1CONbits.TCKPS = 0b10; // Select 1:64 Prescaler
	TMR1 = 0x0000; // Clear timer register
	PR1 = 0x0271; // for 1 ms 625 dec for 1 ms 625*2 for 2 ms and so on 
	IPC0bits.T1IP = 5; // Set Timer1 Interrupt Priority Level
	IFS0bits.T1IF = 0; // Clear Timer1 Interrupt Flag
	IEC0bits.T1IE = 1; // Enable Timer1 interrupt
	T1CONbits.TON = 1; // Start Timer
	return 0;
}
