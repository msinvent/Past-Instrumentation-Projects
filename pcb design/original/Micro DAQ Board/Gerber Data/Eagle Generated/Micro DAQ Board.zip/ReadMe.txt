'Micro DAQ Board' file is the silk screen layer. 
