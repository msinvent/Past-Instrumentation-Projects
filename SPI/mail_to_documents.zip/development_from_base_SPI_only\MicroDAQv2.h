#ifndef __MICRODAQV2_H__
#define __MICRODAQV2_H__ 

#define LED_1 LATAbits.LATA2
#define LED_3 LATAbits.LATA4


// External Functions
extern void cfgClock(void);
extern void cfgPps(void);


#endif
