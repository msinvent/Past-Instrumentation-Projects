#ifndef __ADXL_H__


//This is a list of some of the registers available on the ADXL345.
//To learn more about these and the rest of the registers on the ADXL345, read the datasheet!
extern char POWER_CTL;	//Power Control Register
extern char DATA_FORMAT;
extern char DATAX0;	//X-Axis Data 0
extern char DATAX1;	//X-Axis Data 1
extern char DATAY0;	//Y-Axis Data 0
extern char DATAY1;	//Y-Axis Data 1
extern char DATAZ0;	//Z-Axis Data 0
extern char DATAZ1;	//Z-Axis Data 1 

#define CS LATCbits.LATC6
#define INT1 PORTBbits.RB9
#define TRANSFER PORTBbits.RB6


#define HIGH 1
#define LOW 0

extern char SPI_transfer(char data);
extern void cfgAdxl(void);
extern char getdatacheck(char register_address);
extern char getdata(char register_address);
extern char ff_detect();

extern char adxl_data[11];
extern char IMU_data[16000];

#endif
