//
#ifndef __INTERRUPTS_H__
#define __INTERRUPTS_H__

//extern interrupt declarations

extern void __attribute__ ((__interrupt__,__no_auto_psv__)) _T1Interrupt(void);
extern void __attribute__ ((__interrupt__,__no_auto_psv__)) _U1RXInterrupt(void);
extern void __attribute__ ((__interrupt__,__no_auto_psv__)) _U2RXInterrupt(void);
extern void __attribute__((interrupt, no_auto_psv)) _DMA0Interrupt(void);
extern void __attribute__((interrupt, no_auto_psv)) _DMA1Interrupt(void);
extern void __attribute__((interrupt, no_auto_psv)) _DMA2Interrupt(void);

#endif
