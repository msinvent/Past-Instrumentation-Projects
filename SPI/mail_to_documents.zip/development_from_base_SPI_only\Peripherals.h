#ifndef __PERIPHERALS_H__
#define __PERIPHERALS_H__

//External Functions here

extern void cfgTimerT1(unsigned int priority);
extern void cfgUart1(unsigned int priority);
extern void cfgUart2(unsigned int priority);
extern void cfgSpi1(void);
extern void cfgDma0Uart1Rx(void);
extern void cfgDma1Uart2Rx(void);
extern void cfgDma2Spi1Rx(void);

extern void ProcessSpiRxSamples(unsigned int *SpiRxBuffer);

extern unsigned int Uart1RxBuffA[16] __attribute__((space(dma)));
extern unsigned int Uart1RxBuffB[16] __attribute__((space(dma)));
extern unsigned int Uart2RxBuffA[16] __attribute__((space(dma)));
extern unsigned int Uart2RxBuffB[16] __attribute__((space(dma)));
extern unsigned int Spi1RxBuffA[16] __attribute__((space(dma)));
extern unsigned int Spi1RxBuffB[16] __attribute__((space(dma)));

#endif
