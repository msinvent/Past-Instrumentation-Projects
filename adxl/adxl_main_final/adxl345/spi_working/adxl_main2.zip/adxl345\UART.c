#include<p33FJ128MC804.h>

#define FCY 40000000
#define BAUDRATE1 38400 
#define BAUDRATE2 38400 

#define BRGVAL1 ((FCY/BAUDRATE1)/16)-1
#define BRGVAL2 ((FCY/BAUDRATE2)/16)-1



int configure_UART1(unsigned char priority)
{

	//UART-1
	U1MODEbits.STSEL = 0; // 1 Stop bit
	U1MODEbits.PDSEL = 0; // No Parity, 8 data bits
	U1MODEbits.ABAUD = 0; // Auto-Baud Disabled
	U1MODEbits.BRGH = 0; // low speed mode selected
	U1BRG = BRGVAL1; // BAUD Rate Setting
	//U1STAbits.UTXISEL0 = 0; // Interrupt after one TX Character is transmitted
	//U1STAbits.UTXISEL1 = 0;
	U1MODEbits.UARTEN = 1; // Enable UART
	U1STAbits.UTXEN = 1; // Enable UART TX
	
	U1STAbits.URXISEL = 0; // interrupt when a character is received at RX
	
	//IPC2bits.U1RXIP = priority; // Set UART_1 Receive Interrupt Priority Level
	//IFS0bits.U1RXIF = 0; // Clear UART1_RX Interrupt Flag
	//IEC0bits.U1RXIE = 1; // Enable UART1_RX interrupt
	return 0;
}

int configure_UART2(unsigned char priority)
{

	//UART-2
	U2MODEbits.STSEL = 0; // 1 Stop bit
	U2MODEbits.PDSEL = 0; // No Parity, 8 data bits
	U2MODEbits.ABAUD = 0; // Auto-Baud Disabled
	U2MODEbits.BRGH = 0; // Low Speed mode
	U2BRG = BRGVAL2; // BAUD Rate Setting
	//U2STAbits.UTXISEL0 = 0; // Interrupt after one TX Character is transmitted
	//U2STAbits.UTXISEL1 = 0;
	U2MODEbits.UARTEN = 1; // Enable UART
	U2STAbits.UTXEN = 1; // Enable UART TX

	U2STAbits.URXISEL = 0; // interrupt when a character is received at RX
	
	//IPC7bits.U2RXIP = priority; // Set UART2_RX Receive Interrupt Priority Level
	//IFS1bits.U2RXIF = 0; // Clear UART2_RX Interrupt Flag
	//IEC1bits.U2RXIE = 0; // Disable UART2_RX interrupt
	return 0;
}
