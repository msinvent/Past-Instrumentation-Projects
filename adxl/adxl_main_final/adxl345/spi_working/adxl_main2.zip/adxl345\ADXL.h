#define POWER_CTL 0x2D
#define DATA_FORMAT 0x31
#define DATAX0 0x32
#define DATAX1 0x33
#define DATAY0 0x34
#define DATAY1 0x35
#define DATAZ0 0x36
#define DATAZ1 0x37


#define LOW 0
#define HIGH 1

#define CS LATCbits.LATC5

#define LED_1 LATAbits.LATA2
#define LED_3 LATAbits.LATA4