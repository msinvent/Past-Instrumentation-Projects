#include<p33FJ128MC804.h>

#define TIMER_FREQ 100
//5,10,15,20,25,30 50,55,60,70,100.

int configure_TIMER_T1(unsigned int priority)
{
	T1CONbits.TON = 0;// Disable Timer
	T1CONbits.TCS = 0;// Select internal instruction cycle clock
	T1CONbits.TGATE = 0;// Disable Gated Timer mode
	T1CONbits.TCKPS = 0b11;// Select 1:256 Prescaler
	TMR1 = 0x0000;// Clear timer register
		if(TIMER_FREQ == 50)
		PR1 = 0x0C35;//0xC35 for 50 Hz 0x138 for 5 Hz
		else if(TIMER_FREQ == 100)
		PR1 = 0x061A;
		else if(TIMER_FREQ == 5)
		PR1 = 0x7A12;
		else if(TIMER_FREQ == 10)
		PR1 = 0x3D09;
		else if(TIMER_FREQ == 15)
		PR1 = 0x28B0;
		else if(TIMER_FREQ == 20)
		PR1 = 0x1E84;
		else if(TIMER_FREQ == 25)
		PR1 = 0x186A;
		else if(TIMER_FREQ == 30)
		PR1 = 0x1458;
		else if(TIMER_FREQ == 55)
		PR1 = 0x072E;
		else if(TIMER_FREQ == 60)
		PR1 = 0x06C8;
		else if(TIMER_FREQ == 70)
		PR1 = 0x061A;
		else
		PR1 = 0x7A12;
		
	IPC0bits.T1IP = priority; // Set Timer1 Interrupt Priority Level
	IFS0bits.T1IF = 0; // Clear Timer1 Interrupt Flag
	IEC0bits.T1IE = 1; // Enable Timer1 interrupt
	T1CONbits.TON = 1; // Start Timer
	return PR1;
}
