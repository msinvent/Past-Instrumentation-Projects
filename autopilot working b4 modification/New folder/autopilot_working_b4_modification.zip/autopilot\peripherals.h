#ifndef __PERIPHERALS_H__
#define __PERIPHERALS_H__

//External Functions here

extern void cfgtimerT1(unsigned int priority);
extern void cfguart1(unsigned int priority);
extern void cfguart2(unsigned int priority);
extern void cfgspi1(void);

#endif
