//Programmer : Manish Sharma
//Date : 25/02/2012
//Place : IIT-KANPUR
//Things left : give some delay in the beginning and attach buzzer
//moring program now going to put FREE FALL DETECTION
//program complete and running

#if defined(__dsPIC33F__)
#include "p33Fxxxx.h"
#endif

// have definitions of clock settings and Peripheral Pin mapping
#include "microDAQv2.h"
// have declarations and definitions of Peripherals used
#include "adis16334.h"
// have declarations and definitions of Peripherals used
#include "peripherals.h"


//Enable ALL User Interrupts
void enableinterrupts(void)
{
	/* Set CPU IPL to 0, enable level 1-7 interrupts */
	/* No restoring of previous CPU IPL state performed here */
	INTCON1bits.NSTDIS = 1;		//Disable Interrupt Nesting
	SRbits.IPL = 0;
	return;
}
//End enableInterrupts

//Disable ALL User Interrupts
void disableinterrupts(void)
{
	/* Set CPU IPL to 7, disable level 1-7 interrupts */
	/* No saving of current CPU IPL setting performed here */
	SRbits.IPL = 7;
	return;
}
//End disableInterrupts

int main()
{

	unsigned long i,j;

	cfgclock();
	cfgpps();
	
	//disableinterrupts();

	cfguart1(4);
	cfgtimerT1(4);
	//cfguart2(4);
	
	cfgspi1();

	//enableinterrupts();
	
	LED_1 = 1;LED_3 = 1;	

	for(i=0;i<60000;i++)
		for(j=0;j<100;j++);

	LED_1 = 0;LED_3 = 0;	
	
	for(i=0;i<60000;i++)
		for(j=0;j<100;j++);

	while(1)//background loop
	{
	}

	return 0;
}
 