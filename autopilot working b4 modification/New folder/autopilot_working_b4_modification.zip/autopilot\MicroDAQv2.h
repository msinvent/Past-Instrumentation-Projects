#ifndef __MICRODAQV2_H__
#define __MICRODAQV2_H__ 

#define LED_1 LATAbits.LATA2
#define LED_3 LATAbits.LATA4

#define CS LATBbits.LATB9


// External Functions
extern void cfgclock(void);
extern void cfgpps(void);


#endif
