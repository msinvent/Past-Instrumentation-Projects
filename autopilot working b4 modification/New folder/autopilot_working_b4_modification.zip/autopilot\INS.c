//INS mechanism

volatile double roll= 1;
volatile double pitch= 0;
volatile double yaw= 0;

