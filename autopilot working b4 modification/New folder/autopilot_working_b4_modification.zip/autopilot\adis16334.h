#ifndef __ADIS16334_H__

extern char get_adis_data(int *adis_data);

#endif
