#include<p33FJ128MC804.h>

//Configure the ADC
int configure_ADC(void)
{
	
	//Configure the port pins as Analog pins	
		AD1PCFGLbits.PCFG4 = 0;
		AD1PCFGLbits.PCFG5 = 0;
		//AD1PCFGLbits.PCFG6 = 0;
		//AD1PCFGLbits.PCFG7 = 0;
		//AD1PCFGLbits.PCFG8 = 0;
		
	//Set 12-bit, 1-channel ADC Operation
		AD1CON1bits.AD12B = 1;
		
	//Select the voltage reference to be AVDD & AVSS
		AD1CON2bits.VCFG = 0b000;
		
	//Sample Clock Source Select & Sample Auto-Start
		AD1CON1bits.SSRC = 0b111; //Auto-Convert
	
	//Set Channel A Negative Input 
		AD1CHS0bits.CH0NA = 0;
	
	//ADC Clock derived from the System Clock
		AD1CON3bits.ADRC = 0;	//Tad = Tcy*(ADCS+1)

	//Set ADC Conversion Clock and Auto Sample Time Bits
		//Tconv = 14*Tcy*(ADCS+1)
		AD1CON3bits.ADCS = 3;	//Tad = Tcy*(4+1) = 126.2188nS	
		AD1CON3bits.SAMC = 10;	//Tsamp+conv = (10+14)x126.2188 = 3029.25nS
								//Fsamp+conv = 330.11kHz
	
	//Turn on the ADc and start the 1st conversion
		AD1CON1bits.ASAM = 0; //SAMP bit is manually set
		AD1CON1bits.ADON = 1;
		
	return 0;
}
//End ADC Configuration

//ADC Sampling Routine
unsigned int adc_sample(unsigned char channel)
{
	
	AD1CON1bits.DONE = 0;
	AD1CHS0bits.CH0SA = channel;
	AD1CON1bits.SAMP = 1; //Start Sampling
	while(AD1CON1bits.DONE == 0){}	//Wait while the 
										//conversion is going on
	return ADC1BUF0;
	
}
//End ADC Sampling
