#include<p33FJ128MC804.h>

int configure_TIMER_T1(void)
{
	T1CONbits.TON = 0; // Disable Timer
	T1CONbits.TCS = 0; // Select internal instruction cycle clock
	T1CONbits.TGATE = 0; // Disable Gated Timer mode
	T1CONbits.TCKPS = 0b11; // Select 1:1 Prescaler
	TMR1 = 0x0000; // Clear timer register
	PR1 = 0x0C35;//0x061A 0x08B8 for 70 Hz 0x0C35 for 50 Hz 0x186A Load the period value
	IPC0bits.T1IP = 4; // Set Timer1 Interrupt Priority Level
	IFS0bits.T1IF = 0; // Clear Timer1 Interrupt Flag
	IEC0bits.T1IE = 1; // Enable Timer1 interrupt
	T1CONbits.TON = 1; // Start Timer
	return 0;
}
